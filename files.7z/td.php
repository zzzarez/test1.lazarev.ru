<?php
	echo date("m.d.y  H:i:s");
?>